Simple examples --- Compile with

gcc -Wall -Wextra 01_example_IntegersSTACK.c IntegersStack.c -o 01_example_IntegersSTACK

gcc -Wall -Wextra 02_example_PointersSTACK.c PointersStack.c -o 02_example_PointersSTACK

STACK of pointers to 2D Points --- Compile with

gcc -Wall -Wextra PointersStack.c Point2D_XY.c 03_example_STACK_Point2D.c -o 03_example_Point2D_STACK -lm

gcc -Wall -Wextra PointersStack.c Point2D_Polar.c 03_example_STACK_Point2D.c -o 03_example_Point2D_STACK -lm
