
*** Use ADT POINTERS LIST as a basis for ADT POINTERS DEQUE ***

1 - Establish the interface of ADT POPINTERS DEQUE, without any reference to the ADT POINTERS LIST - PointersDeque.h

2 - Establish the internal representation using ADT POINTERS LIST - PointersDeque.c

3 - Implement the required DEQUE functions, using the corresponding POINTERS LIST functions

4 - Test with new application examples

